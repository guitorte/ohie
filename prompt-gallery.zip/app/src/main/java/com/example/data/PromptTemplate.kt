package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "prompt_templates")
data class PromptTemplate(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val promptContent: String, // String with placeholders like {subject}, {lighting}, etc.
    val negativePrompt: String? = null,
    val category: String = "General" // e.g., "Portrait", "Anime", "Landscape"
) : Serializable
