package com.example.data

import com.example.R
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.firstOrNull

class PromptRepository(
    private val promptImageDao: PromptImageDao,
    private val promptTemplateDao: PromptTemplateDao
) {
    val allImages: Flow<List<PromptImage>> = promptImageDao.getAllImages()
    val favoriteImages: Flow<List<PromptImage>> = promptImageDao.getFavoriteImages()
    val allTemplates: Flow<List<PromptTemplate>> = promptTemplateDao.getAllTemplates()

    fun searchImages(query: String): Flow<List<PromptImage>> {
        return if (query.isBlank()) {
            promptImageDao.getAllImages()
        } else {
            promptImageDao.searchImages("%$query%")
        }
    }

    fun getImageById(id: Long): Flow<PromptImage?> {
        return promptImageDao.getImageById(id)
    }

    suspend fun insertImage(image: PromptImage): Long {
        return promptImageDao.insertImage(image)
    }

    suspend fun insertImages(images: List<PromptImage>): List<Long> {
        return promptImageDao.insertImages(images)
    }

    suspend fun updateImage(image: PromptImage) {
        promptImageDao.updateImage(image)
    }

    suspend fun deleteImage(image: PromptImage) {
        promptImageDao.deleteImage(image)
    }

    suspend fun deleteImagesByIds(ids: List<Long>) {
        promptImageDao.deleteImagesByIds(ids)
    }

    suspend fun bulkFavoriteImages(ids: List<Long>, isFavorite: Boolean) {
        promptImageDao.bulkFavoriteImages(ids, isFavorite)
    }

    suspend fun bulkMoveToFolder(ids: List<Long>, folder: String?) {
        promptImageDao.bulkMoveToFolder(ids, folder)
    }

    suspend fun bulkSetCollections(ids: List<Long>, collections: String) {
        promptImageDao.bulkSetCollections(ids, collections)
    }

    // Custom helper for bulk appending tags
    suspend fun bulkAddTags(ids: List<Long>, newTags: List<String>) {
        if (newTags.isEmpty() || ids.isEmpty()) return
        
        // Flow reads can be fetched synchronously via first() inside coroutine
        for (id in ids) {
            val img = promptImageDao.getImageById(id).firstOrNull() ?: continue
            val existingTags = img.getTagsList()
            val updatedTags = (existingTags + newTags).distinct()
            promptImageDao.updateImage(img.copy(tags = updatedTags.joinToString(",")))
        }
    }

    suspend fun insertTemplate(template: PromptTemplate): Long {
        return promptTemplateDao.insertTemplate(template)
    }

    suspend fun updateTemplate(template: PromptTemplate) {
        promptTemplateDao.updateTemplate(template)
    }

    suspend fun deleteTemplate(template: PromptTemplate) {
        promptTemplateDao.deleteTemplate(template)
    }

    suspend fun prePopulateIfEmpty() {
        if (promptImageDao.getImageCount() == 0) {
            // Seeding Sample Images
            val sampleImages = listOf(
                PromptImage(
                    title = "The Cybernetic Muse",
                    prompt = "A cinematic masterclass photo of a futuristic cybernetic woman, neon glowing face micro-circuits, hyper-detailed, unreal engine 5 render, dark moody studio lighting, 3:4 aspect ratio",
                    negativePrompt = "ugly, deformed, blurry, low contrast, mutated hands, out of focus, duplicate, worst quality, frame, text, signature",
                    drawableId = R.drawable.img_sample_portrait,
                    modelUsed = "Midjourney v6",
                    aspectRatio = "3:4",
                    seed = "88271923",
                    sampler = "DPM++ 2M Karras",
                    cfg = 7.0f,
                    steps = 35,
                    tags = "Cyberpunk,Portrait,Neon,Female,Sci-Fi",
                    collections = "Portraits,Sci-Fi",
                    isFavorite = true,
                    rating = 5,
                    colorLabel = "Cyan",
                    customNotes = "My favorite cyberpunk theme. Beautiful glowing micro-traces on cheek and temples.",
                    creationDate = System.currentTimeMillis() - 7200000 // 2 hours ago
                ),
                PromptImage(
                    title = "Nebula Spires of Celestia",
                    prompt = "An expansive floating celestial crystal castle fantasy landscape, vibrant cosmic nebula clouds in a starry night sky, digital painting, majestic, 4:3 aspect ratio",
                    negativePrompt = "sketch, photorealistic, modern cars, cityscape, buildings, low resolution, watermarks, text, watermark",
                    drawableId = R.drawable.img_sample_landscape,
                    modelUsed = "Flux.1 Dev",
                    aspectRatio = "4:3",
                    seed = "492011923",
                    sampler = "Euler",
                    cfg = 3.5f,
                    steps = 28,
                    tags = "Landscape,Fantasy,Cosmic,Nebula,Castle,Scenic",
                    collections = "Landscapes,Fantasy",
                    isFavorite = false,
                    rating = 4,
                    colorLabel = "Purple",
                    customNotes = "Excellent color grading in the original render. Great sky details.",
                    creationDate = System.currentTimeMillis() - 3600000 // 1 hour ago
                ),
                PromptImage(
                    title = "August Golden Hour Street",
                    prompt = "A retro 90s anime aesthetic scene of a cozy street at sunset, detailed clouds, warm golden light, hand-drawn digital art style, beautiful, 3:4 aspect ratio",
                    negativePrompt = "photorealistic, render, 3d, worst quality, modern, modern cars, signature, text, watermark",
                    drawableId = R.drawable.img_sample_anime,
                    modelUsed = "Niji Journeys v6",
                    aspectRatio = "3:4",
                    seed = "109282",
                    sampler = "Euler a",
                    cfg = 6.0f,
                    steps = 30,
                    tags = "Anime,Cozy,Retro,Sunset,Clouds,Street",
                    collections = "Anime,Scenic",
                    isFavorite = true,
                    rating = 5,
                    colorLabel = "Orange",
                    customNotes = "Evokes beautiful nostalgia. Perfect warm backlight on telegraph poles.",
                    creationDate = System.currentTimeMillis()
                )
            )
            promptImageDao.insertImages(sampleImages)

            // Seeding Sample Templates
            val sampleTemplates = listOf(
                PromptTemplate(
                    name = "Cinematic Portrait Template",
                    promptContent = "A cinematic masterclass portrait of {subject}, highly detailed, gorgeous studio volumetric lighting, photorealistic, {aspect_ratio}",
                    negativePrompt = "ugly, deformed, blurry, worst quality, text, logos, watermark",
                    category = "Portrait"
                ),
                PromptTemplate(
                    name = "Retro Anime Scene Template",
                    promptContent = "90s retro anime aesthetic illustration of {scenery}, cozy mood, warm golden colors, detailed hand-drawn art, vintage look, masterpiece",
                    negativePrompt = "photorealistic, render, 3d, worst quality, modern, signature, text",
                    category = "Anime"
                ),
                PromptTemplate(
                    name = "Fantasy World Landscape Template",
                    promptContent = "An epic high-fantasy landscape depicting {location}, magical realism, vibrant colors, atmospheric depth, celestial lighting, high-detail digital painting",
                    negativePrompt = "buildings, modern structures, cars, low contrast, noise, draft, watermark",
                    category = "Landscape"
                )
            )
            promptTemplateDao.insertTemplates(sampleTemplates)
        }
    }
}
