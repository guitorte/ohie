package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [PromptImage::class, PromptTemplate::class], version = 1, exportSchema = false)
abstract class PromptDatabase : RoomDatabase() {

    abstract fun promptImageDao(): PromptImageDao
    abstract fun promptTemplateDao(): PromptTemplateDao

    companion object {
        @Volatile
        private var INSTANCE: PromptDatabase? = null

        fun getDatabase(context: Context): PromptDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    PromptDatabase::class.java,
                    "prompt_gallery_database"
                )
                    .fallbackToDestructiveMigration() // Simple design for robust app prototyping
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
