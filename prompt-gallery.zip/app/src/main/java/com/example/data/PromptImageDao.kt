package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface PromptImageDao {

    @Query("SELECT * FROM prompt_images ORDER BY creationDate DESC")
    fun getAllImages(): Flow<List<PromptImage>>

    @Query("""
        SELECT * FROM prompt_images 
        WHERE prompt LIKE :query 
           OR negativePrompt LIKE :query 
           OR title LIKE :query 
           OR tags LIKE :query 
           OR customNotes LIKE :query 
           OR modelUsed LIKE :query 
           OR collections LIKE :query
           OR folder LIKE :query
        ORDER BY creationDate DESC
    """)
    fun searchImages(query: String): Flow<List<PromptImage>>

    @Query("SELECT * FROM prompt_images WHERE isFavorite = 1 ORDER BY creationDate DESC")
    fun getFavoriteImages(): Flow<List<PromptImage>>

    @Query("SELECT * FROM prompt_images WHERE id = :id")
    fun getImageById(id: Long): Flow<PromptImage?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertImage(image: PromptImage): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertImages(images: List<PromptImage>): List<Long>

    @Update
    suspend fun updateImage(image: PromptImage)

    @Delete
    suspend fun deleteImage(image: PromptImage)

    @Query("DELETE FROM prompt_images WHERE id IN (:ids)")
    suspend fun deleteImagesByIds(ids: List<Long>)

    // Bulk Favorites
    @Query("UPDATE prompt_images SET isFavorite = :isFavorite WHERE id IN (:ids)")
    suspend fun bulkFavoriteImages(ids: List<Long>, isFavorite: Boolean)

    // Bulk Move to Folder
    @Query("UPDATE prompt_images SET folder = :folder WHERE id IN (:ids)")
    suspend fun bulkMoveToFolder(ids: List<Long>, folder: String?)

    // Bulk Assign Collection
    @Query("UPDATE prompt_images SET collections = :collections WHERE id IN (:ids)")
    suspend fun bulkSetCollections(ids: List<Long>, collections: String)

    // Simple count of all items
    @Query("SELECT COUNT(*) FROM prompt_images")
    suspend fun getImageCount(): Int
}
