package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface PromptTemplateDao {

    @Query("SELECT * FROM prompt_templates ORDER BY id DESC")
    fun getAllTemplates(): Flow<List<PromptTemplate>>

    @Query("SELECT * FROM prompt_templates WHERE id = :id")
    fun getTemplateById(id: Long): Flow<PromptTemplate?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTemplate(template: PromptTemplate): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTemplates(templates: List<PromptTemplate>): List<Long>

    @Update
    suspend fun updateTemplate(template: PromptTemplate)

    @Delete
    suspend fun deleteTemplate(template: PromptTemplate)
}
