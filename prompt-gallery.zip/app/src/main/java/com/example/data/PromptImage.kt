package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "prompt_images")
data class PromptImage(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val uri: String? = null, // URI of imported/cropped image
    val drawableId: Int? = null, // Resource ID for high-quality preset art
    val title: String,
    val prompt: String,
    val negativePrompt: String? = null,
    val description: String? = null,
    val tags: String = "", // Comma-separated list of tags
    val creationDate: Long = System.currentTimeMillis(),
    val importDate: Long = System.currentTimeMillis(),
    val modelUsed: String = "Unknown",
    val aspectRatio: String = "1:1",
    val seed: String? = null,
    val sampler: String? = null,
    val cfg: Float? = null,
    val steps: Int? = null,
    val isFavorite: Boolean = false,
    val rating: Int = 0, // 0 to 5 stars
    val colorLabel: String? = null, // e.g., "Red", "Blue", "Green", "Yellow", "Purple"
    val collections: String = "", // Comma-separated list of collections
    val folder: String? = null, // Folder organization
    val customNotes: String? = null,
    val sourceUrl: String? = null
) : Serializable {
    
    // Helper to get tags as list
    fun getTagsList(): List<String> {
        return if (tags.isBlank()) emptyList() else tags.split(",").map { it.trim() }.filter { it.isNotEmpty() }
    }

    // Helper to get collections as list
    fun getCollectionsList(): List<String> {
        return if (collections.isBlank()) emptyList() else collections.split(",").map { it.trim() }.filter { it.isNotEmpty() }
    }
}
