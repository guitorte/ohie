package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.PromptTemplate
import com.example.viewmodel.PromptViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TemplatesScreen(
    viewModel: PromptViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val templates by viewModel.allTemplates.collectAsStateWithLifecycle()
    
    var showAddDialog by remember { mutableStateOf(false) }
    var editingTemplate: PromptTemplate? by remember { mutableStateOf(null) }
    
    var name by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var negativeContent by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Portrait") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Prompt Templates") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            editingTemplate = null
                            name = ""
                            content = ""
                            negativeContent = ""
                            category = "Portrait"
                            showAddDialog = true
                        },
                        modifier = Modifier.testTag("add_template_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Create Template")
                    }
                }
            )
        },
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (templates.isEmpty()) {
                Column(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        modifier = Modifier.size(64.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                    )
                    Text("No Templates Configured", fontWeight = FontWeight.Bold)
                    Text(
                        "Add custom prompt structural layouts with wildcards such as {subject} or {lighting} to quickly reuse during artwork seeding.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.widthIn(max = 280.dp),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    Button(onClick = {
                        editingTemplate = null
                        name = ""
                        content = ""
                        negativeContent = ""
                        category = "Portrait"
                        showAddDialog = true
                    }) {
                        Text("Add First Template")
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(160.dp),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(templates, key = { it.id }) { template ->
                        Card(
                            onClick = {
                                editingTemplate = template
                                name = template.name
                                content = template.promptContent
                                negativeContent = template.negativePrompt ?: ""
                                category = template.category
                                showAddDialog = true
                            },
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = template.category.uppercase(),
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        IconButton(
                                            onClick = {
                                                clipboardManager.setText(AnnotatedString(template.promptContent))
                                                Toast.makeText(context, "Template Copied!", Toast.LENGTH_SHORT).show()
                                            },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy Template", modifier = Modifier.size(14.dp))
                                        }
                                        IconButton(
                                            onClick = { viewModel.deleteTemplate(template) },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(Icons.Default.Delete, contentDescription = "Delete Template", modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.error)
                                        }
                                    }
                                }
                                
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(template.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = template.promptContent,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 4,
                                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Add/Edit Dialog sheet
    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text(if (editingTemplate == null) "Create Template" else "Edit Template") },
            text = {
                Column(
                    modifier = Modifier.width(320.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Template Name") },
                        placeholder = { Text("e.g. Dreamy Cyberpunk") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    
                    OutlinedTextField(
                        value = category,
                        onValueChange = { category = it },
                        label = { Text("Category") },
                        placeholder = { Text("e.g. Portrait, Abstract") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    
                    OutlinedTextField(
                        value = content,
                        onValueChange = { content = it },
                        label = { Text("Template Prompt Content") },
                        placeholder = { Text("A {subject}, hyperdetailed, 3D render, digital art with {color_scheme} lighting") },
                        modifier = Modifier.fillMaxWidth().height(100.dp)
                    )

                    OutlinedTextField(
                        value = negativeContent,
                        onValueChange = { negativeContent = it },
                        label = { Text("Negative Prompt Template") },
                        placeholder = { Text("ugly, blur, signature, out of focus") },
                        modifier = Modifier.fillMaxWidth().height(80.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (name.isBlank() || content.isBlank()) {
                            Toast.makeText(context, "Fill Name and Prompt Content", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        
                        if (editingTemplate == null) {
                            viewModel.addTemplate(
                                name = name,
                                promptContent = content,
                                negativePrompt = negativeContent.ifBlank { null },
                                category = category
                            )
                            Toast.makeText(context, "Template Created!", Toast.LENGTH_SHORT).show()
                        } else {
                            val updated = editingTemplate!!.copy(
                                name = name,
                                promptContent = content,
                                negativePrompt = negativeContent.ifBlank { null },
                                category = category
                            )
                            viewModel.updateTemplate(updated)
                            Toast.makeText(context, "Template Updated!", Toast.LENGTH_SHORT).show()
                        }
                        showAddDialog = false
                    },
                    modifier = Modifier.testTag("confirm_template_save")
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

// Ext custom mutable helper mapping
@Composable
fun rememberStateByText(): MutableState<Boolean> = remember { mutableStateOf(false) }
