package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.R
import com.example.data.PromptImage
import com.example.viewmodel.PromptViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditImageScreen(
    imageId: Long?,
    viewModel: PromptViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val allTemplates by viewModel.allTemplates.collectAsStateWithLifecycle()
    
    // Check if editing or adding
    val isEditing = imageId != null
    var originalImage: PromptImage? by remember { mutableStateOf(null) }
    
    // Fields
    var title by remember { mutableStateOf("") }
    var prompt by remember { mutableStateOf("") }
    var negativePrompt by remember { mutableStateOf("") }
    var tagsInput by remember { mutableStateOf("") }
    var modelUsed by remember { mutableStateOf("Flux.1 Dev") }
    var aspectRatio by remember { mutableStateOf("1:1") }
    var seed by remember { mutableStateOf("") }
    var sampler by remember { mutableStateOf("Euler") }
    var cfgInput by remember { mutableStateOf("3.5") }
    var stepsInput by remember { mutableStateOf("28") }
    var rating by remember { mutableStateOf(0) }
    var colorLabel by remember { mutableStateOf<String?>(null) }
    var collectionsInput by remember { mutableStateOf("") }
    var folderInput by remember { mutableStateOf("") }
    var customNotes by remember { mutableStateOf("") }
    
    // Image reference uri or drawableId
    var selectedImageUri by remember { mutableStateOf<String?>(null) }
    var selectedDrawableId by remember { mutableStateOf<Int?>(null) }
    
    // UI selection dialogs
    var showTemplateLoader by remember { mutableStateOf(false) }
    var showPlaceholderLoader by remember { mutableStateOf(false) }

    // Launcher for real device file select
    val fileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            // Persist permission to read this URI persistently if possible
            try {
                context.contentResolver.takePersistableUriPermission(
                    it,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (e: Exception) {
                // Ignore safe errors on custom emulators
            }
            selectedImageUri = it.toString()
            selectedDrawableId = null
            Toast.makeText(context, "Image Loaded Successfully!", Toast.LENGTH_SHORT).show()
        }
    }

    // Load original data if editing
    LaunchedEffect(imageId) {
        if (isEditing) {
            viewModel.getImageById(imageId!!).collect { img ->
                if (img != null && originalImage == null) {
                    originalImage = img
                    title = img.title
                    prompt = img.prompt
                    negativePrompt = img.negativePrompt ?: ""
                    tagsInput = img.tags
                    modelUsed = img.modelUsed
                    aspectRatio = img.aspectRatio
                    seed = img.seed ?: ""
                    sampler = img.sampler ?: ""
                    cfgInput = img.cfg?.toString() ?: ""
                    stepsInput = img.steps?.toString() ?: ""
                    rating = img.rating
                    colorLabel = img.colorLabel
                    collectionsInput = img.collections
                    folderInput = img.folder ?: ""
                    customNotes = img.customNotes ?: ""
                    selectedImageUri = img.uri
                    selectedDrawableId = img.drawableId
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (isEditing) "Edit Metadata" else "Import New Prompt Art") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("form_back_button")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            if (prompt.isBlank()) {
                                Toast.makeText(context, "Please enter a generation prompt", Toast.LENGTH_SHORT).show()
                                return@IconButton
                            }
                            
                            val cfg = cfgInput.toFloatOrNull()
                            val steps = stepsInput.toIntOrNull()
                            
                            if (isEditing && originalImage != null) {
                                val updated = originalImage!!.copy(
                                    title = title.ifBlank { "Untitled Prompt" },
                                    prompt = prompt,
                                    negativePrompt = negativePrompt.ifBlank { null },
                                    tags = tagsInput,
                                    modelUsed = modelUsed,
                                    aspectRatio = aspectRatio,
                                    seed = seed.ifBlank { null },
                                    sampler = sampler.ifBlank { null },
                                    cfg = cfg,
                                    steps = steps,
                                    rating = rating,
                                    colorLabel = colorLabel,
                                    collections = collectionsInput,
                                    folder = folderInput.ifBlank { null },
                                    customNotes = customNotes.ifBlank { null },
                                    uri = selectedImageUri,
                                    drawableId = selectedDrawableId
                                )
                                viewModel.updateImage(updated)
                                Toast.makeText(context, "Metadata Updated!", Toast.LENGTH_SHORT).show()
                            } else {
                                viewModel.addImage(
                                    title = title,
                                    prompt = prompt,
                                    negativePrompt = negativePrompt.ifBlank { null },
                                    uri = selectedImageUri,
                                    drawableId = selectedDrawableId,
                                    tags = tagsInput,
                                    modelUsed = modelUsed,
                                    aspectRatio = aspectRatio,
                                    seed = seed.ifBlank { null },
                                    sampler = sampler.ifBlank { null },
                                    cfg = cfg,
                                    steps = steps,
                                    rating = rating,
                                    colorLabel = colorLabel,
                                    collections = collectionsInput,
                                    folder = folderInput.ifBlank { null },
                                    customNotes = customNotes
                                )
                                Toast.makeText(context, "New Art Added to Gallery!", Toast.LENGTH_SHORT).show()
                            }
                            onNavigateBack()
                        },
                        modifier = Modifier.testTag("save_art_button")
                    ) {
                        Icon(Icons.Default.Save, contentDescription = "Save")
                    }
                }
            )
        },
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Interactive Image Selector Panel
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clickable { showPlaceholderLoader = true },
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    if (selectedDrawableId != null) {
                        AsyncImage(
                            model = selectedDrawableId,
                            contentDescription = "Selected Art Preview",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else if (selectedImageUri != null) {
                        AsyncImage(
                            model = selectedImageUri,
                            contentDescription = "Selected Art Preview",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Column(
                            modifier = Modifier.align(Alignment.Center),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.CloudUpload, contentDescription = "", modifier = Modifier.size(48.dp))
                            Text("Select AI Art Work Detail", fontWeight = FontWeight.SemiBold)
                            Text("Tap to Choose Local File or Preset Art", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    
                    // Small Edit overlay label icon
                    if (selectedDrawableId != null || selectedImageUri != null) {
                        Surface(
                            color = Color.Black.copy(alpha = 0.6f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(12.dp)
                        ) {
                            Text(
                                "CHANGE IMAGE",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            // Title Input
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Title") },
                placeholder = { Text("e.g. Neon Cyber Angel") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("title_field"),
                shape = RoundedCornerShape(8.dp)
            )

            // Prompt Area (With Load Template Tool!)
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Original Art Prompt", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    if (allTemplates.isNotEmpty()) {
                        TextButton(onClick = { showTemplateLoader = true }) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = "", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Load Template", fontSize = 12.sp)
                        }
                    }
                }
                
                OutlinedTextField(
                    value = prompt,
                    onValueChange = { prompt = it },
                    placeholder = { Text("Enter the original Prompt generated by the model...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp)
                        .testTag("prompt_field"),
                    shape = RoundedCornerShape(8.dp)
                )
            }

            // Negative Prompt
            OutlinedTextField(
                value = negativePrompt,
                onValueChange = { negativePrompt = it },
                label = { Text("Negative Prompt") },
                placeholder = { Text("List terms used to exclude from generation...") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(84.dp)
                    .testTag("negative_prompt_field"),
                shape = RoundedCornerShape(8.dp)
            )

            // AI Model used selection
            val modelPresets = listOf("Flux.1 Dev", "Flux.1 Schnell", "Midjourney v6", "Niji v6", "DALL-E 3", "Stable Diffusion XL")
            var expandedModelDropdown by remember { mutableStateOf(false) }
            Box(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = modelUsed,
                    onValueChange = { modelUsed = it },
                    label = { Text("AI Model Used") },
                    trailingIcon = {
                        IconButton(onClick = { expandedModelDropdown = true }) {
                            Icon(Icons.Default.ArrowDropDown, contentDescription = "")
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                )
                DropdownMenu(
                    expanded = expandedModelDropdown,
                    onDismissRequest = { expandedModelDropdown = false },
                    modifier = Modifier.fillMaxWidth(0.9f)
                ) {
                    modelPresets.forEach { modelPreset ->
                        DropdownMenuItem(
                            text = { Text(modelPreset) },
                            onClick = {
                                modelUsed = modelPreset
                                expandedModelDropdown = false
                            }
                        )
                    }
                }
            }

            // Aspect Ratio selection
            val aspectRatiosPresets = listOf("1:1", "3:4", "4:3", "9:16", "16:9")
            var expandedAspectDropdown by remember { mutableStateOf(false) }
            Box(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = aspectRatio,
                    onValueChange = { aspectRatio = it },
                    label = { Text("Aspect Ratio") },
                    trailingIcon = {
                        IconButton(onClick = { expandedAspectDropdown = true }) {
                            Icon(Icons.Default.ArrowDropDown, contentDescription = "")
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                )
                DropdownMenu(
                    expanded = expandedAspectDropdown,
                    onDismissRequest = { expandedAspectDropdown = false }
                ) {
                    aspectRatiosPresets.forEach { presetRatio ->
                        DropdownMenuItem(
                            text = { Text(presetRatio) },
                            onClick = {
                                aspectRatio = presetRatio
                                expandedAspectDropdown = false
                            }
                        )
                    }
                }
            }

            // Generation Parameters: Seed, Sampler, CFG, Steps
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = seed,
                    onValueChange = { seed = it },
                    label = { Text("Seed") },
                    placeholder = { Text("e.g. 52932") },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp)
                )
                OutlinedTextField(
                    value = sampler,
                    onValueChange = { sampler = it },
                    label = { Text("Sampler") },
                    placeholder = { Text("e.g. Euler a") },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = cfgInput,
                    onValueChange = { cfgInput = it },
                    label = { Text("CFG Scale") },
                    placeholder = { Text("e.g. 7.5") },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp)
                )
                OutlinedTextField(
                    value = stepsInput,
                    onValueChange = { stepsInput = it },
                    label = { Text("Steps") },
                    placeholder = { Text("e.g. 30") },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp)
                )
            }

            // Organizing: Folder, Collections, Tags, Color Labels
            OutlinedTextField(
                value = folderInput,
                onValueChange = { folderInput = it },
                label = { Text("Folder Name") },
                placeholder = { Text("e.g. Concept Art") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp)
            )

            OutlinedTextField(
                value = collectionsInput,
                onValueChange = { collectionsInput = it },
                label = { Text("Collections (comma-separated)") },
                placeholder = { Text("e.g. Anime, Landscapes") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp)
            )

            OutlinedTextField(
                value = tagsInput,
                onValueChange = { tagsInput = it },
                label = { Text("Tags (comma-separated)") },
                placeholder = { Text("e.g. cyber, futuristic, neon") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp)
            )

            // Color label selector circular tray
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Accent Color Label", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val colorsList = listOf("Cyan", "Purple", "Orange", "Red", "Blue", "Green", "Yellow", "Pink")
                    colorsList.forEach { colName ->
                        val labelCol = mapColorLabel(colName)
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(labelCol)
                                .border(
                                    width = if (colorLabel == colName) 3.dp else 1.dp,
                                    color = if (colorLabel == colName) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.5f),
                                    shape = CircleShape
                                )
                                .clickable {
                                    colorLabel = if (colorLabel == colName) null else colName
                                }
                        )
                    }
                }
            }

            // Quality Rating
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Quality Rating", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    (1..5).forEach { star ->
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "$star Stars",
                            tint = if (star <= rating) Color(0xFFFFD700) else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f),
                            modifier = Modifier
                                .size(36.dp)
                                .clickable { rating = star }
                        )
                    }
                }
            }

            // Custom Artist Notes
            OutlinedTextField(
                value = customNotes,
                onValueChange = { customNotes = it },
                label = { Text("Artist Notes & Annotation") },
                placeholder = { Text("Write personal review, generation challenges, or modifications to make...") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(100.dp),
                shape = RoundedCornerShape(8.dp)
            )

            Button(
                onClick = {
                    if (prompt.isBlank()) {
                        Toast.makeText(context, "Please enter a generation prompt", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    
                    val cfg = cfgInput.toFloatOrNull()
                    val steps = stepsInput.toIntOrNull()
                    
                    if (isEditing && originalImage != null) {
                        viewModel.updateImage(originalImage!!.copy(
                            title = title.ifBlank { "Untitled" },
                            prompt = prompt,
                            negativePrompt = negativePrompt.ifBlank { null },
                            tags = tagsInput,
                            modelUsed = modelUsed,
                            aspectRatio = aspectRatio,
                            seed = seed.ifBlank { null },
                            sampler = sampler.ifBlank { null },
                            cfg = cfg,
                            steps = steps,
                            rating = rating,
                            colorLabel = colorLabel,
                            collections = collectionsInput,
                            folder = folderInput.ifBlank { null },
                            customNotes = customNotes.ifBlank { null },
                            uri = selectedImageUri,
                            drawableId = selectedDrawableId
                        ))
                    } else {
                        viewModel.addImage(
                            title = title,
                            prompt = prompt,
                            negativePrompt = negativePrompt.ifBlank { null },
                            uri = selectedImageUri,
                            drawableId = selectedDrawableId,
                            tags = tagsInput,
                            modelUsed = modelUsed,
                            aspectRatio = aspectRatio,
                            seed = seed.ifBlank { null },
                            sampler = sampler.ifBlank { null },
                            cfg = cfg,
                            steps = steps,
                            rating = rating,
                            colorLabel = colorLabel,
                            collections = collectionsInput,
                            folder = folderInput.ifBlank { null },
                            customNotes = customNotes
                        )
                    }
                    onNavigateBack()
                },
                modifier = Modifier.fillMaxWidth().height(52.dp).testTag("submit_form_button"),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(if (isEditing) "Update Details" else "Import Art Work")
            }
            
            Spacer(modifier = Modifier.height(32.dp))
        }
    }

    // Load templates Dialog
    if (showTemplateLoader) {
        AlertDialog(
            onDismissRequest = { showTemplateLoader = false },
            title = { Text("Select Prompt Template") },
            text = {
                Column(
                    modifier = Modifier.heightIn(max = 300.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    allTemplates.forEach { template ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    prompt = template.promptContent
                                    negativePrompt = template.negativePrompt ?: ""
                                    showTemplateLoader = false
                                },
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(template.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                Text(template.category, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    template.promptContent,
                                    fontSize = 11.sp,
                                    maxLines = 2,
                                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showTemplateLoader = false }) {
                    Text("Close")
                }
            }
        )
    }

    // Modal Image selector tool type: real file pick vs preset seeder pack
    if (showPlaceholderLoader) {
        AlertDialog(
            onDismissRequest = { showPlaceholderLoader = false },
            title = { Text("Choose Source") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            fileLauncher.launch("image/*")
                            showPlaceholderLoader = false
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.UploadFile, contentDescription = "")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Pick Real Image File")
                    }
                    
                    Text("Or Select Sample Preset Art Work:", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        PresetArtBox(
                            imgRes = R.drawable.img_sample_portrait,
                            name = "Portrait",
                            onClick = {
                                selectedDrawableId = R.drawable.img_sample_portrait
                                selectedImageUri = null
                                showPlaceholderLoader = false
                                Toast.makeText(context, "Seeded Cybernetic Portrait Chosen", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.weight(1f)
                        )
                        PresetArtBox(
                            imgRes = R.drawable.img_sample_landscape,
                            name = "Landscape",
                            onClick = {
                                selectedDrawableId = R.drawable.img_sample_landscape
                                selectedImageUri = null
                                showPlaceholderLoader = false
                                Toast.makeText(context, "Seeded Floating Landscape Chosen", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.weight(1f)
                        )
                        PresetArtBox(
                            imgRes = R.drawable.img_sample_anime,
                            name = "Anime",
                            onClick = {
                                selectedDrawableId = R.drawable.img_sample_anime
                                selectedImageUri = null
                                showPlaceholderLoader = false
                                Toast.makeText(context, "Seeded Tokyo Sunset Chosen", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            },
            confirmButton = {}
        )
    }
}

@Composable
fun PresetArtBox(
    imgRes: Int,
    name: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier.clickable { onClick() }
    ) {
        AsyncImage(
            model = imgRes,
            contentDescription = "",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(64.dp)
                .clip(RoundedCornerShape(8.dp))
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(name, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    }
}
