package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.PromptImage
import com.example.viewmodel.GalleryStyle
import com.example.viewmodel.PromptViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun GalleryScreen(
    viewModel: PromptViewModel,
    onNavigateToDetail: (Long) -> Unit,
    onNavigateToAddEdit: (Long?) -> Unit,
    onNavigateToTemplates: () -> Unit,
    onNavigateToImportExport: () -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    
    val images by viewModel.filteredImages.collectAsStateWithLifecycle()
    val allImagesCount by viewModel.allImages.collectAsStateWithLifecycle()
    val selectedIds by viewModel.selectedImages.collectAsStateWithLifecycle()
    val isMultiSelect by viewModel.isMultiSelectActive.collectAsStateWithLifecycle()
    
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val activeStyle by viewModel.galleryStyle.collectAsStateWithLifecycle()
    
    // Filters States
    val activeCollectionFilter by viewModel.selectedCollectionFilter.collectAsStateWithLifecycle()
    val activeFolderFilter by viewModel.selectedFolderFilter.collectAsStateWithLifecycle()
    val activeTagFilter by viewModel.selectedTagFilter.collectAsStateWithLifecycle()
    val activeColorFilter by viewModel.selectedColorFilter.collectAsStateWithLifecycle()
    
    val availableCollections by viewModel.availableCollections.collectAsStateWithLifecycle()
    val availableFolders by viewModel.availableFolders.collectAsStateWithLifecycle()
    val availableTags by viewModel.availableTags.collectAsStateWithLifecycle()
    
    var showFilterSheet by remember { mutableStateOf(false) }
    var showBulkActionDialog by remember { mutableStateOf(false) }
    var bulkFolderInput by remember { mutableStateOf("") }
    var bulkCollectionInput by remember { mutableStateOf("") }
    var bulkTagsInput by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.background)
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                // Main Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = if (isMultiSelect) "${selectedIds.size} Selected" else "Prompt Gallery",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        ),
                        color = if (isMultiSelect) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                    )
                    
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (isMultiSelect) {
                            IconButton(
                                onClick = { viewModel.clearSelection() },
                                modifier = Modifier.testTag("clear_selection_button")
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "Cancel Multi-select")
                            }
                            IconButton(
                                onClick = { showBulkActionDialog = true },
                                modifier = Modifier.testTag("bulk_ops_button")
                            ) {
                                Icon(Icons.Default.Build, contentDescription = "Bulk Actions")
                            }
                        } else {
                            IconButton(onClick = onNavigateToTemplates) {
                                Icon(Icons.Outlined.AutoAwesome, contentDescription = "Templates")
                            }
                            IconButton(onClick = onNavigateToImportExport) {
                                Icon(Icons.Outlined.Backup, contentDescription = "Backup & Import")
                            }
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                // Search Input Field
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.searchQuery.value = it },
                    placeholder = { Text("Search title, prompts, tags, models...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search Icon") },
                    trailingIcon = {
                        Row {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(
                                    onClick = { viewModel.searchQuery.value = "" },
                                    modifier = Modifier.testTag("clear_search")
                                ) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear search")
                                }
                            }
                            IconButton(onClick = { showFilterSheet = true }) {
                                Icon(
                                    imageVector = if (activeCollectionFilter != null || activeFolderFilter != null || activeTagFilter != null || activeColorFilter != null) {
                                        Icons.Filled.FilterAlt
                                    } else {
                                        Icons.Outlined.FilterAlt
                                    },
                                    contentDescription = "Filters Options",
                                    tint = if (activeCollectionFilter != null || activeFolderFilter != null || activeTagFilter != null || activeColorFilter != null) {
                                        MaterialTheme.colorScheme.primary
                                    } else {
                                        MaterialTheme.colorScheme.onSurface
                                    }
                                )
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("search_input"),
                    shape = CircleShape,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent
                    ),
                    singleLine = true
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                // View Style Switcher Row & Active Filters Display
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Style Choice
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        GalleryStyleTab(
                            icon = Icons.Default.GridView,
                            label = "Grid",
                            active = activeStyle == GalleryStyle.GRID,
                            onClick = { viewModel.galleryStyle.value = GalleryStyle.GRID }
                        )
                        GalleryStyleTab(
                            icon = Icons.Default.Dashboard,
                            label = "Masonry",
                            active = activeStyle == GalleryStyle.MASONRY,
                            onClick = { viewModel.galleryStyle.value = GalleryStyle.MASONRY }
                        )
                        GalleryStyleTab(
                            icon = Icons.Default.CalendarToday,
                            label = "Timeline",
                            active = activeStyle == GalleryStyle.TIMELINE,
                            onClick = { viewModel.galleryStyle.value = GalleryStyle.TIMELINE }
                        )
                        GalleryStyleTab(
                            icon = Icons.Default.Favorite,
                            label = "Favorites",
                            active = activeStyle == GalleryStyle.FAVORITES,
                            onClick = { viewModel.galleryStyle.value = GalleryStyle.FAVORITES }
                        )
                    }
                    
                    // Reset filters option if any is applied
                    if (activeCollectionFilter != null || activeFolderFilter != null || activeTagFilter != null || activeColorFilter != null) {
                        TextButton(
                            onClick = { viewModel.resetAllFilters() },
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text("Reset Filters", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                
                // Active Filters Chips Row
                if (activeFolderFilter != null || activeCollectionFilter != null || activeTagFilter != null || activeColorFilter != null) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        activeFolderFilter?.let {
                            FilterIndicatorChip(text = "Folder: $it") { viewModel.selectedFolderFilter.value = null }
                        }
                        activeCollectionFilter?.let {
                            FilterIndicatorChip(text = "Collection: $it") { viewModel.selectedCollectionFilter.value = null }
                        }
                        activeTagFilter?.let {
                            FilterIndicatorChip(text = "#$it") { viewModel.selectedTagFilter.value = null }
                        }
                        activeColorFilter?.let {
                            FilterIndicatorChip(text = "Color: $it") { viewModel.selectedColorFilter.value = null }
                        }
                    }
                }
            }
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { onNavigateToAddEdit(null) },
                icon = { Icon(Icons.Default.Add, contentDescription = "Import Prompt Art") },
                text = { Text("Add Art") },
                modifier = Modifier.testTag("add_art_fab"),
                expanded = activeStyle != GalleryStyle.MASONRY
            )
        },
        bottomBar = {
            // Bulk Operations Floating Bar at the bottom
            AnimatedVisibility(
                visible = isMultiSelect,
                enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
            ) {
                Surface(
                    tonalElevation = 8.dp,
                    shadowElevation = 8.dp,
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding(),
                    shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButtonWithLabel(
                            icon = Icons.Default.Favorite,
                            label = "Fav",
                            onClick = { viewModel.bulkFavorite(true) }
                        )
                        IconButtonWithLabel(
                            icon = Icons.Default.FavoriteBorder,
                            label = "Unfav",
                            onClick = { viewModel.bulkFavorite(false) }
                        )
                        IconButtonWithLabel(
                            icon = Icons.Default.CreateNewFolder,
                            label = "Move",
                            onClick = { showBulkActionDialog = true }
                        )
                        IconButtonWithLabel(
                            icon = Icons.Default.Delete,
                            label = "Delete",
                            onClick = { viewModel.bulkDelete() },
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.testTag("bulk_delete_button")
                        )
                    }
                }
            }
        },
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (images.isEmpty()) {
                // Stunning Empty state
                Column(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.PhotoLibrary,
                        contentDescription = "No images found",
                        modifier = Modifier.size(72.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                    )
                    Text(
                        text = if (allImagesCount.isEmpty()) "Gallery is Empty" else "No matching prompts",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = if (allImagesCount.isEmpty()) "Create or import your favorite AI generation images alongside their prompts and metadata." else "Try adjusting your filters, tags, colors, or query terms.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.widthIn(max = 280.dp),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    if (allImagesCount.isEmpty()) {
                        Button(onClick = { onNavigateToAddEdit(null) }) {
                            Text("Create Starter Prompt")
                        }
                    }
                }
            } else {
                // Visual displays options
                when (activeStyle) {
                    GalleryStyle.GRID -> {
                        LazyVerticalGrid(
                            columns = GridCells.Adaptive(110.dp),
                            contentPadding = PaddingValues(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(images, key = { it.id }) { image ->
                                PromptImageCard(
                                    image = image,
                                    isSelected = selectedIds.contains(image.id),
                                    isMultiSelectActive = isMultiSelect,
                                    onClick = {
                                        if (isMultiSelect) {
                                            viewModel.toggleSelectImage(image.id)
                                        } else {
                                            onNavigateToDetail(image.id)
                                        }
                                    },
                                    onLongClick = {
                                        viewModel.toggleSelectImage(image.id)
                                    },
                                    onQuickCopyPrompt = {
                                        clipboardManager.setText(AnnotatedString(image.prompt))
                                        Toast.makeText(context, "Prompt Copied!", Toast.LENGTH_SHORT).show()
                                    }
                                )
                            }
                        }
                    }
                    GalleryStyle.MASONRY -> {
                        LazyVerticalStaggeredGrid(
                            columns = StaggeredGridCells.Adaptive(150.dp),
                            contentPadding = PaddingValues(8.dp),
                            verticalItemSpacing = 8.dp,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(images, key = { it.id }) { image ->
                                PromptImageCard(
                                    image = image,
                                    isSelected = selectedIds.contains(image.id),
                                    isMultiSelectActive = isMultiSelect,
                                    onClick = {
                                        if (isMultiSelect) {
                                            viewModel.toggleSelectImage(image.id)
                                        } else {
                                            onNavigateToDetail(image.id)
                                        }
                                    },
                                    onLongClick = {
                                        viewModel.toggleSelectImage(image.id)
                                    },
                                    onQuickCopyPrompt = {
                                        clipboardManager.setText(AnnotatedString(image.prompt))
                                        Toast.makeText(context, "Prompt Copied!", Toast.LENGTH_SHORT).show()
                                    },
                                    staggered = true
                                )
                            }
                        }
                    }
                    GalleryStyle.TIMELINE -> {
                        // Chronological grouped layout
                        val grouped = remember(images) {
                            images.groupBy {
                                SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(Date(it.creationDate))
                            }
                        }
                        
                        LazyColumn(
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            grouped.forEach { (month, monthImages) ->
                                item {
                                    Text(
                                        text = month,
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.padding(bottom = 8.dp)
                                    )
                                }
                                
                                item {
                                    LazyVerticalGrid(
                                        columns = GridCells.Adaptive(100.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        modifier = Modifier.heightIn(max = 2000.dp) // Dynamic height within bounded views
                                    ) {
                                        items(monthImages, key = { it.id }) { image ->
                                            PromptImageCard(
                                                image = image,
                                                isSelected = selectedIds.contains(image.id),
                                                isMultiSelectActive = isMultiSelect,
                                                onClick = {
                                                    if (isMultiSelect) {
                                                        viewModel.toggleSelectImage(image.id)
                                                    } else {
                                                        onNavigateToDetail(image.id)
                                                    }
                                                },
                                                onLongClick = {
                                                    viewModel.toggleSelectImage(image.id)
                                                },
                                                onQuickCopyPrompt = {
                                                    clipboardManager.setText(AnnotatedString(image.prompt))
                                                    Toast.makeText(context, "Prompt Copied!", Toast.LENGTH_SHORT).show()
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else -> {} // Cover other styles fallback safely
                }
            }
        }
    }
    
    // Bottom Sheet for filtering options
    if (showFilterSheet) {
        ModalBottomSheet(
            onDismissRequest = { showFilterSheet = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
                    .navigationBarsPadding(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Filter Options",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    TextButton(onClick = { viewModel.resetAllFilters(); showFilterSheet = false }) {
                        Text("Clear All")
                    }
                }
                
                Divider()
                
                // Color Labels Filter Display
                Text("Color Labels", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val colorsList = listOf("Cyan", "Red", "Blue", "Green", "Yellow", "Orange", "Purple", "Pink")
                    colorsList.forEach { colName ->
                        val labelCol = mapColorLabel(colName)
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(labelCol)
                                .border(
                                    width = if (activeColorFilter == colName) 3.dp else 1.dp,
                                    color = if (activeColorFilter == colName) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.5f),
                                    shape = CircleShape
                                )
                                .combinedClickable(
                                    onClick = {
                                        viewModel.selectedColorFilter.value = if (activeColorFilter == colName) null else colName
                                    }
                                )
                        )
                    }
                }
                
                // Folders filter
                if (availableFolders.isNotEmpty()) {
                    Text("Folders", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium))
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(100.dp),
                        modifier = Modifier.heightIn(max = 120.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(availableFolders) { folder ->
                            FilterSelectableChip(
                                text = folder,
                                selected = activeFolderFilter == folder,
                                onClick = {
                                    viewModel.selectedFolderFilter.value = if (activeFolderFilter == folder) null else folder
                                }
                            )
                        }
                    }
                }

                // Collections filter
                if (availableCollections.isNotEmpty()) {
                    Text("Collections", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium))
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(100.dp),
                        modifier = Modifier.heightIn(max = 120.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(availableCollections) { collection ->
                            FilterSelectableChip(
                                text = collection,
                                selected = activeCollectionFilter == collection,
                                onClick = {
                                    viewModel.selectedCollectionFilter.value = if (activeCollectionFilter == collection) null else collection
                                }
                            )
                        }
                    }
                }

                // Tags Filter
                if (availableTags.isNotEmpty()) {
                    Text("Tags", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium))
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(90.dp),
                        modifier = Modifier.heightIn(max = 120.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(availableTags) { tag ->
                            FilterSelectableChip(
                                text = "#$tag",
                                selected = activeTagFilter == tag,
                                onClick = {
                                    viewModel.selectedTagFilter.value = if (activeTagFilter == tag) null else tag
                                }
                            )
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = { showFilterSheet = false },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Apply Filters")
                }
            }
        }
    }
    
    // Bulk Operations Prompt Inputs Drawer
    if (showBulkActionDialog) {
        AlertDialog(
            onDismissRequest = { showBulkActionDialog = false },
            title = { Text("Bulk Operations (${selectedIds.size} selected)") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Assign Folder", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    OutlinedTextField(
                        value = bulkFolderInput,
                        onValueChange = { bulkFolderInput = it },
                        placeholder = { Text("e.g. Concept Art") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    
                    Text("Assign Collection", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    OutlinedTextField(
                        value = bulkCollectionInput,
                        onValueChange = { bulkCollectionInput = it },
                        placeholder = { Text("e.g. Portraits") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    
                    Text("Add Tags", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    OutlinedTextField(
                        value = bulkTagsInput,
                        onValueChange = { bulkTagsInput = it },
                        placeholder = { Text("e.g. hyperreal, photorealistic") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (bulkFolderInput.isNotBlank()) {
                            viewModel.bulkMoveToFolder(bulkFolderInput.trim())
                        }
                        if (bulkCollectionInput.isNotBlank()) {
                            viewModel.bulkAssignCollection(bulkCollectionInput.trim())
                        }
                        if (bulkTagsInput.isNotBlank()) {
                            val list = bulkTagsInput.split(",").map { it.trim() }.filter { it.isNotEmpty() }
                            viewModel.bulkAddTags(list)
                        }
                        showBulkActionDialog = false
                    }
                ) {
                    Text("Apply Changes")
                }
            },
            dismissButton = {
                TextButton(onClick = { showBulkActionDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun PromptImageCard(
    image: PromptImage,
    isSelected: Boolean,
    isMultiSelectActive: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onQuickCopyPrompt: () -> Unit,
    staggered: Boolean = false
) {
    // Generate height mapping for staggered aspect ratios beautifully
    val cardHeight = when {
        staggered && image.aspectRatio == "16:9" -> 110.dp
        staggered && image.aspectRatio == "4:3" -> 140.dp
        staggered && image.aspectRatio == "3:4" -> 210.dp
        staggered -> 160.dp
        else -> 120.dp
    }
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(cardHeight)
            .border(
                width = if (isSelected) 3.dp else 0.dp,
                color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                shape = RoundedCornerShape(24.dp)
            )
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            ),
        shape = RoundedCornerShape(24.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Render the Image (Supports drawable elements or URI beautifully)
            if (image.drawableId != null) {
                AsyncImage(
                    model = image.drawableId,
                    contentDescription = image.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else if (!image.uri.isNullOrBlank()) {
                AsyncImage(
                    model = image.uri,
                    contentDescription = image.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                // Color Label backdrop fallback placeholder
                val fallbackBrush = Brush.verticalGradient(
                    colors = listOf(
                        mapColorLabel(image.colorLabel).copy(alpha = 0.5f),
                        MaterialTheme.colorScheme.surfaceVariant
                    )
                )
                Box(modifier = Modifier.fillMaxSize().background(fallbackBrush))
            }
            
            // Image overlays (Gradients and quick actions)
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.75f)),
                            startY = 100f
                        )
                    )
            )
            
            // Quick favorites star indicator
            if (image.isFavorite) {
                Icon(
                    imageVector = Icons.Filled.Star,
                    contentDescription = "Favorited",
                    tint = Color(0xFFFFD700),
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp)
                        .size(16.dp)
                )
            }
            
            // Color Label corner indicator
            image.colorLabel?.let {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(8.dp)
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(mapColorLabel(it))
                )
            }
            
            // Bottom Information Overlay Layout
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth()
                    .padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Text(
                    text = image.title,
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = image.prompt,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.75f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            
            // Select Overlay indicator
            if (isMultiSelectActive) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                            else Color.Black.copy(alpha = 0.1f)
                        )
                ) {
                    RadioButton(
                        selected = isSelected,
                        onClick = onClick,
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(4.dp)
                    )
                }
            } else {
                // Quick Tap Copy overlay on hover/card (Or just showing a small copy button)
                IconButton(
                    onClick = onQuickCopyPrompt,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(4.dp)
                        .size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Quick Copy Prompt",
                        tint = Color.White.copy(alpha = 0.85f),
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun GalleryStyleTab(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    active: Boolean,
    onClick: () -> Unit
) {
    InputChip(
        selected = active,
        onClick = onClick,
        label = { Text(label, fontSize = 11.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Normal) },
        leadingIcon = { Icon(icon, contentDescription = label, modifier = Modifier.size(14.dp)) },
        colors = InputChipDefaults.inputChipColors(
            selectedContainerColor = MaterialTheme.colorScheme.primary,
            selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
            selectedLeadingIconColor = MaterialTheme.colorScheme.onPrimary
        )
    )
}

@Composable
fun FilterIndicatorChip(
    text: String,
    onRemove: () -> Unit
) {
    AssistChip(
        onClick = {},
        label = { Text(text, fontSize = 11.sp) },
        trailingIcon = {
            IconButton(onClick = onRemove, modifier = Modifier.size(14.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Remove filter", modifier = Modifier.size(10.dp))
            }
        },
        shape = RoundedCornerShape(16.dp)
    )
}

@Composable
fun FilterSelectableChip(
    text: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(text, fontSize = 11.sp) },
        shape = RoundedCornerShape(16.dp)
    )
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun IconButtonWithLabel(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit,
    tint: Color = MaterialTheme.colorScheme.onPrimaryContainer,
    modifier: Modifier = Modifier
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = modifier.combinedClickable { onClick() }
    ) {
        IconButton(onClick = onClick) {
            Icon(icon, contentDescription = label, tint = tint)
        }
        Text(label, style = MaterialTheme.typography.labelSmall, color = tint.copy(alpha = 0.8f))
    }
}

// Maps color label string to standard M3 Colors
fun mapColorLabel(colorName: String?): Color {
    return when (colorName?.lowercase()) {
        "cyan" -> Color(0xFF00E5FF)
        "purple" -> Color(0xFFD500F9)
        "orange" -> Color(0xFFFF6D00)
        "red" -> Color(0xFFFF1744)
        "blue" -> Color(0xFF2979FF)
        "green" -> Color(0xFF00E676)
        "yellow" -> Color(0xFFFFEA00)
        "pink" -> Color(0xFFF50057)
        "emerald" -> Color(0xFF097969)
        "slate" -> Color(0xFF708090)
        else -> Color.Gray
    }
}
