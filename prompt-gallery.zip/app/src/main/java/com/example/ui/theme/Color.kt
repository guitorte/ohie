package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Clean Minimalism Palette (Material 3 inspired)
val PrimaryPurple = Color(0xFF6750A4)
val OnPrimaryWhite = Color(0xFFFFFFFF)
val PrimaryContainerSoft = Color(0xFFE8DEF8)
val OnPrimaryContainerDark = Color(0xFF1D192B)

val SecondaryGray = Color(0xFF625B71)
val SecondaryContainerSoft = Color(0xFFE8DFF5)

val BackgroundClean = Color(0xFFFDFBFF)
val OnBackgroundSlate = Color(0xFF1C1B1F)

val SurfaceClean = Color(0xFFFDFBFF)
val OnSurfaceSlate = Color(0xFF191C1E)
val SurfaceVariantClean = Color(0xFFEEE7F2) // Matches top header/search in HTML
val OnSurfaceVariantSlate = Color(0xFF49454F)

// Dark minimalist theme variants
val PrimaryPurpleDark = Color(0xFFD0BCFF)
val OnPrimaryDark = Color(0xFF381E72)
val PrimaryContainerDark = Color(0xFF4F378B)
val OnPrimaryContainerLight = Color(0xFFE8DEF8)

val BackgroundDark = Color(0xFF121114)
val SurfaceDark = Color(0xFF121114)
val SurfaceVariantDark = Color(0xFF2A282F)
