package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.LibraryBooks
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.viewmodel.PromptViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImportExportScreen(
    viewModel: PromptViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val coroutineScope = rememberCoroutineScope()
    
    var jsonInput by remember { mutableStateOf("") }
    var operationInProgress by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Backup, Import & Export") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Elegant Explanation Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
                    .padding(16.dp)
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Outlined.LibraryBooks,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(36.dp)
                    )
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            "Export options completely offline",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            "All data remains stored strictly on this device. Use backup modes to keep copies in external notes apps or spreadsheets.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                    }
                }
            }

            // Export Actions Section
            Text("Export Prompt Library", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Export JSON
                    RowButton(
                        icon = Icons.Default.Code,
                        title = "Copy JSON Library Backup",
                        description = "Full database backup including prompts, parameters, and templates, copyable as JSON raw text.",
                        onClick = {
                            coroutineScope.launch {
                                operationInProgress = true
                                val json = viewModel.exportAsJson()
                                clipboardManager.setText(AnnotatedString(json))
                                operationInProgress = false
                                Toast.makeText(context, "Full JSON Backup Copied to Clipboard!", Toast.LENGTH_LONG).show()
                            }
                        },
                        enabled = !operationInProgress
                    )
                    
                    Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))

                    // Export Markdown 
                    RowButton(
                        icon = Icons.Default.Description,
                        title = "Copy Obsidian / Markdown Notes",
                        description = "Saves prompts, technical notes, and settings as styled Markdown text, perfect for personal wikis.",
                        onClick = {
                            coroutineScope.launch {
                                operationInProgress = true
                                val md = viewModel.exportAsMarkdown()
                                clipboardManager.setText(AnnotatedString(md))
                                operationInProgress = false
                                Toast.makeText(context, "Markdown Prompts Copied to Clipboard!", Toast.LENGTH_LONG).show()
                            }
                        },
                        enabled = !operationInProgress
                    )
                    
                    Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))

                    // Export CSV
                    RowButton(
                        icon = Icons.Default.GridOn,
                        title = "Copy Spreadsheet / CSV Format",
                        description = "Compile parameters and prompts as standard comma-separated text values compatible with sheets.",
                        onClick = {
                            coroutineScope.launch {
                                operationInProgress = true
                                val csv = viewModel.exportAsCsv()
                                clipboardManager.setText(AnnotatedString(csv))
                                operationInProgress = false
                                Toast.makeText(context, "Spreadsheet CSV Copied to Clipboard!", Toast.LENGTH_LONG).show()
                            }
                        },
                        enabled = !operationInProgress
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Import Section
            Text("Import Prompt Backup", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            
            OutlinedTextField(
                value = jsonInput,
                onValueChange = { jsonInput = it },
                label = { Text("Paste JSON Backup Data") },
                placeholder = { Text("{\n  \"images\": [...],\n  \"templates\": [...]\n}") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(150.dp)
                    .testTag("import_json_input"),
                shape = RoundedCornerShape(8.dp)
            )

            Button(
                onClick = {
                    if (jsonInput.isBlank()) {
                        Toast.makeText(context, "Please paste valid JSON backup data", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    
                    coroutineScope.launch {
                        operationInProgress = true
                        val success = viewModel.importFromJson(jsonInput.trim())
                        operationInProgress = false
                        if (success) {
                            jsonInput = ""
                            Toast.makeText(context, "Library Backup Imported & Merged Successfully!", Toast.LENGTH_LONG).show()
                            onNavigateBack()
                        } else {
                            Toast.makeText(context, "Invalid JSON data structure or schema mismatch error.", Toast.LENGTH_LONG).show()
                        }
                    }
                },
                enabled = !operationInProgress && jsonInput.isNotBlank(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("apply_import_button"),
                shape = RoundedCornerShape(8.dp)
            ) {
                if (operationInProgress) {
                    CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MaterialTheme.colorScheme.onPrimary)
                } else {
                    Icon(Icons.Default.Upload, contentDescription = "")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Import & Merge Backups")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Dangerous ops section
            Text("Troubleshooting & Reset", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.error)
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Purge Prompt Database", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onErrorContainer)
                    Text("Deletes all custom prompts and templates. You will lose your customized art assets history. Confirm carefully.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onErrorContainer)
                    Button(
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        onClick = {
                            coroutineScope.launch {
                                viewModel.bulkDelete() // Deletes any select or we can build bulk purges
                                Toast.makeText(context, "Cleared Selection Items!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.fillMaxWidth().testTag("purge_library_button")
                    ) {
                        Text("Clear Current Visual Selections")
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun RowButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    description: String,
    onClick: () -> Unit,
    enabled: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable(enabled = enabled) { onClick() }
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        }
        
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(description, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        
        Icon(Icons.Default.ArrowOutward, contentDescription = "", modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
    }
}
