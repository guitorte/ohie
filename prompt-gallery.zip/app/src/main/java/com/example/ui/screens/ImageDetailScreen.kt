package com.example.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.PromptImage
import com.example.viewmodel.PromptViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImageDetailScreen(
    imageId: Long,
    viewModel: PromptViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToEdit: (Long) -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    
    // Reactive observing of single item
    val imageProduct by viewModel.getImageById(imageId).collectAsStateWithLifecycle(initialValue = null)
    
    var isExpandedPromptCard by remember { mutableStateOf(true) }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(imageProduct?.title ?: "Prompt Details") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("back_button")) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    imageProduct?.let { img ->
                        IconButton(
                            onClick = { viewModel.updateImage(img.copy(isFavorite = !img.isFavorite)) },
                            modifier = Modifier.testTag("detail_favorite_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = "Toggle Favorite",
                                tint = if (img.isFavorite) Color(0xFFFFD700) else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.35f)
                            )
                        }
                        IconButton(
                            onClick = {
                                val clone = img.copy(
                                    id = 0,
                                    title = "${img.title} (Copy)",
                                    creationDate = System.currentTimeMillis()
                                )
                                viewModel.addImage(
                                    title = clone.title,
                                    prompt = clone.prompt,
                                    negativePrompt = clone.negativePrompt,
                                    uri = clone.uri,
                                    drawableId = clone.drawableId,
                                    description = clone.description,
                                    tags = clone.tags,
                                    modelUsed = clone.modelUsed,
                                    aspectRatio = clone.aspectRatio,
                                    seed = clone.seed,
                                    sampler = clone.sampler,
                                    cfg = clone.cfg,
                                    steps = clone.steps,
                                    isFavorite = clone.isFavorite,
                                    rating = clone.rating,
                                    colorLabel = clone.colorLabel,
                                    collections = clone.collections,
                                    folder = clone.folder,
                                    customNotes = clone.customNotes
                                )
                                Toast.makeText(context, "Prompt Duplicated!", Toast.LENGTH_SHORT).show()
                                onNavigateBack()
                            },
                            modifier = Modifier.testTag("detail_duplicate_button")
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Duplicate Prompt Record")
                        }
                        IconButton(
                            onClick = { onNavigateToEdit(img.id) },
                            modifier = Modifier.testTag("detail_edit_button")
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit Metadatas")
                        }
                        IconButton(
                            onClick = {
                                val sendIntent: Intent = Intent().apply {
                                    action = Intent.ACTION_SEND
                                    putExtra(Intent.EXTRA_TEXT, "Prompt: ${img.prompt}\n\nNegative Prompt: ${img.negativePrompt ?: "None"}\n\nAI Model: ${img.modelUsed}")
                                    type = "text/plain"
                                }
                                val shareIntent = Intent.createChooser(sendIntent, null)
                                context.startActivity(shareIntent)
                            },
                            modifier = Modifier.testTag("detail_share_button")
                        ) {
                            Icon(Icons.Default.Share, contentDescription = "Share Prompt Text")
                        }
                    }
                }
            )
        },
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        if (imageProduct == null) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            val img = imageProduct!!
            
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Large Visual Image Preview Card 
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    if (img.drawableId != null) {
                        AsyncImage(
                            model = img.drawableId,
                            contentDescription = img.title,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else if (!img.uri.isNullOrBlank()) {
                        AsyncImage(
                            model = img.uri,
                            contentDescription = img.title,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        // Background gradient labeled
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(mapColorLabel(img.colorLabel).copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.ImageNotSupported,
                                contentDescription = "No High Res Image",
                                modifier = Modifier.size(64.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                            )
                        }
                    }
                    
                    // Quick tag of Aspect ratio inside image box
                    Surface(
                        color = Color.Black.copy(alpha = 0.6f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(12.dp)
                    ) {
                        Text(
                            text = "Aspect Ratio: ${img.aspectRatio}",
                            fontSize = 11.sp,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                // Interactive expandable Prompt Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp)
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Default.Terminal, contentDescription = "Prompt Icon", tint = MaterialTheme.colorScheme.primary)
                                Text(
                                    text = "Generation Prompt",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleMedium
                                )
                            }
                            
                            IconButton(onClick = { isExpandedPromptCard = !isExpandedPromptCard }) {
                                Icon(
                                    imageVector = if (isExpandedPromptCard) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                    contentDescription = if (isExpandedPromptCard) "Collapse" else "Expand"
                                )
                            }
                        }

                        AnimatedVisibility(visible = isExpandedPromptCard) {
                            Column(modifier = Modifier.padding(top = 12.dp)) {
                                // Full Prompt Box with copy trigger
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(MaterialTheme.colorScheme.surfaceColorAtElevation(4.dp))
                                        .border(
                                            1.dp,
                                            MaterialTheme.colorScheme.outline.copy(alpha = 0.2f),
                                            RoundedCornerShape(12.dp)
                                        )
                                        .clickable {
                                            clipboardManager.setText(AnnotatedString(img.prompt))
                                            Toast.makeText(context, "Prompt Copied with One Tap!", Toast.LENGTH_SHORT).show()
                                        }
                                        .padding(16.dp)
                                ) {
                                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Text(
                                            text = img.prompt,
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.End,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                Icons.Default.ContentCopy,
                                                contentDescription = "Copy Prompt Icon",
                                                modifier = Modifier.size(16.dp),
                                                tint = MaterialTheme.colorScheme.primary
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = "TAP TO COPY",
                                                fontWeight = FontWeight.Bold,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                    }
                                }

                                // Negative Prompt display if present
                                img.negativePrompt?.let { neg ->
                                    if (neg.isNotBlank()) {
                                        Spacer(modifier = Modifier.height(16.dp))
                                        Text(
                                            text = "Negative Prompt",
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.titleSmall
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(12.dp))
                                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                                                .border(
                                                    1.dp,
                                                    MaterialTheme.colorScheme.outline.copy(alpha = 0.1f),
                                                    RoundedCornerShape(12.dp)
                                                )
                                                .clickable {
                                                    clipboardManager.setText(AnnotatedString(neg))
                                                    Toast.makeText(context, "Negative Prompt Copied!", Toast.LENGTH_SHORT).show()
                                                }
                                                .padding(12.dp)
                                        ) {
                                            Column {
                                                Text(
                                                    text = neg,
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.End,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Icon(
                                                        Icons.Default.ContentCopy,
                                                        contentDescription = "Copy Neg",
                                                        modifier = Modifier.size(12.dp),
                                                        tint = MaterialTheme.colorScheme.primary
                                                    )
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text(
                                                        text = "COPY NEGATIVE",
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = MaterialTheme.colorScheme.primary
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Metadata Parameters Grid Section
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Attributes & Parameters",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )

                    // Color label, Folder, and Rating Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Card(
                            modifier = Modifier.weight(1f),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("Color Label", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariantState() ?: MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Box(
                                        modifier = Modifier
                                            .size(16.dp)
                                            .clip(CircleShape)
                                            .background(mapColorLabel(img.colorLabel))
                                    )
                                    Text(
                                        text = img.colorLabel ?: "None",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                }
                            }
                        }
                        
                        Card(
                            modifier = Modifier.weight(1f),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text("Folder", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = img.folder ?: "Root",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodyMedium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }

                    // Interactive Rating Card
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Quality Rating", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("How good is this prompt?", style = MaterialTheme.typography.bodySmall)
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                (1..5).forEach { star ->
                                    Icon(
                                        imageVector = Icons.Default.Star,
                                        contentDescription = "$star Stars",
                                        tint = if (star <= img.rating) Color(0xFFFFD700) else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f),
                                        modifier = Modifier
                                            .size(28.dp)
                                            .clickable {
                                                viewModel.updateImage(img.copy(rating = star))
                                            }
                                    )
                                }
                            }
                        }
                    }

                    // Tech Specs details grid: Seed, Sampler, CFG, Steps, AI Model
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp))
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            // AI Model
                            MetadataRow(label = "AI Model Used", value = img.modelUsed)
                            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
                            
                            // Seed
                            MetadataRow(label = "Seed", value = img.seed ?: "Random / Default")
                            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
                            
                            // Sampler
                            MetadataRow(label = "Sampler", value = img.sampler ?: "Standard")
                            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
                            
                            // CFG Scale and Steps
                            Row(modifier = Modifier.fillMaxWidth()) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("CFG Scale", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(img.cfg?.toString() ?: "Default", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Steps / Sampling Steps", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(img.steps?.toString() ?: "Default", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                        }
                    }

                    // Tags displays
                    if (img.getTagsList().isNotEmpty()) {
                        Text("Tags", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            img.getTagsList().forEach { tag ->
                                AssistChip(
                                    onClick = {
                                        viewModel.selectedTagFilter.value = tag
                                        onNavigateBack()
                                    },
                                    label = { Text("#$tag") }
                                )
                            }
                        }
                    }

                    // Collections Displays
                    if (img.getCollectionsList().isNotEmpty()) {
                        Text("Collections", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            img.getCollectionsList().forEach { collection ->
                                InputChip(
                                    selected = false,
                                    onClick = {
                                        viewModel.selectedCollectionFilter.value = collection
                                        onNavigateBack()
                                    },
                                    label = { Text(collection) },
                                    leadingIcon = { Icon(Icons.Default.Folder, contentDescription = null, modifier = Modifier.size(12.dp)) }
                                )
                            }
                        }
                    }

                    // Custom Notes Section
                    if (!img.customNotes.isNullOrBlank()) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(1.dp))
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Icon(Icons.Default.Notes, contentDescription = "", modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                                    Text("Custom Artist Notes", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = img.customNotes,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(32.dp))
                }
            }
        }
    }
}

@Composable
fun MetadataRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
    }
}

// Ext helper indicator
fun ColorScheme.onSurfaceVariantState(): Color? = null
