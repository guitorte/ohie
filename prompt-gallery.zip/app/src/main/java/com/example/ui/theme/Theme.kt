package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = PrimaryPurpleDark,
    onPrimary = OnPrimaryDark,
    primaryContainer = PrimaryContainerDark,
    onPrimaryContainer = OnPrimaryContainerLight,
    background = BackgroundDark,
    onBackground = OnPrimaryContainerLight,
    surface = SurfaceDark,
    onSurface = OnPrimaryContainerLight,
    surfaceVariant = SurfaceVariantDark,
    onSurfaceVariant = OnPrimaryContainerLight
  )

private val LightColorScheme =
  lightColorScheme(
    primary = PrimaryPurple,
    onPrimary = OnPrimaryWhite,
    primaryContainer = PrimaryContainerSoft,
    onPrimaryContainer = OnPrimaryContainerDark,
    secondary = SecondaryGray,
    secondaryContainer = SecondaryContainerSoft,
    onSecondaryContainer = OnPrimaryContainerDark,
    background = BackgroundClean,
    onBackground = OnBackgroundSlate,
    surface = SurfaceClean,
    onSurface = OnSurfaceSlate,
    surfaceVariant = SurfaceVariantClean,
    onSurfaceVariant = OnSurfaceVariantSlate
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Disabling dynamic colors by default so that the Clean Minimalism palette is shown
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
