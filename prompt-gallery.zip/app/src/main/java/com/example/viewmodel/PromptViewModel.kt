package com.example.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.PromptApplication
import com.example.data.PromptImage
import com.example.data.PromptRepository
import com.example.data.PromptTemplate
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

enum class GalleryStyle {
    MASONRY, GRID, TIMELINE, FOLDERS, FAVORITES
}

data class PromptLibraryBackup(
    val images: List<PromptImage>,
    val templates: List<PromptTemplate>
)

class PromptViewModel(
    application: Application,
    private val repository: PromptRepository
) : AndroidViewModel(application) {

    // Main States from Database
    val allImages: StateFlow<List<PromptImage>> = repository.allImages
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favoriteImages: StateFlow<List<PromptImage>> = repository.favoriteImages
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTemplates: StateFlow<List<PromptTemplate>> = repository.allTemplates
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // UI Search & Filter states
    val searchQuery = MutableStateFlow("")
    val galleryStyle = MutableStateFlow(GalleryStyle.GRID)
    val selectedImages = MutableStateFlow<Set<Long>>(emptySet())
    val isMultiSelectActive = selectedImages.map { it.isNotEmpty() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    // Current selection filters
    val selectedCollectionFilter = MutableStateFlow<String?>(null)
    val selectedFolderFilter = MutableStateFlow<String?>(null)
    val selectedTagFilter = MutableStateFlow<String?>(null)
    val selectedColorFilter = MutableStateFlow<String?>(null)

    // Combined & Filtered Images Flow
    val filteredImages: StateFlow<List<PromptImage>> = combine(
        allImages,
        searchQuery,
        galleryStyle,
        selectedCollectionFilter,
        selectedFolderFilter,
        selectedTagFilter,
        selectedColorFilter
    ) { flowValues ->
        @Suppress("UNCHECKED_CAST")
        val images = flowValues[0] as List<PromptImage>
        val query = flowValues[1] as String
        val style = flowValues[2] as GalleryStyle
        val collection = flowValues[3] as String?
        val folder = flowValues[4] as String?
        val tag = flowValues[5] as String?
        val color = flowValues[6] as String?

        var list = images

        // Handle structural views
        if (style == GalleryStyle.FAVORITES) {
            list = list.filter { it.isFavorite }
        }

        // Apply folder filter
        if (folder != null) {
            list = list.filter { it.folder == folder }
        }

        // Apply collection filter
        if (collection != null) {
            list = list.filter { img ->
                img.getCollectionsList().any { it.equals(collection, ignoreCase = true) }
            }
        }

        // Apply tag filter
        if (tag != null) {
            list = list.filter { img ->
                img.getTagsList().any { it.equals(tag, ignoreCase = true) }
            }
        }

        // Apply color label filter
        if (color != null) {
            list = list.filter { it.colorLabel == color }
        }

        // Apply query search (typo tolerance, parts matching, tags, title, prompt search)
        if (query.isNotBlank()) {
            val terms = query.lowercase().split(" ").filter { it.isNotBlank() }
            list = list.filter { img ->
                terms.all { term ->
                    img.title.lowercase().contains(term) ||
                    img.prompt.lowercase().contains(term) ||
                    img.negativePrompt?.lowercase()?.contains(term) == true ||
                    img.tags.lowercase().contains(term) ||
                    img.modelUsed.lowercase().contains(term) ||
                    img.collections.lowercase().contains(term) ||
                    img.customNotes?.lowercase()?.contains(term) == true ||
                    img.folder?.lowercase()?.contains(term) == true
                }
            }
        }

        list
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // All distinct collections, folders, tags, and colors present across all images
    val availableCollections = allImages.map { list ->
        list.flatMap { it.getCollectionsList() }.distinct().sorted()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val availableFolders = allImages.map { list ->
        list.mapNotNull { it.folder }.filter { it.isNotBlank() }.distinct().sorted()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val availableTags = allImages.map { list ->
        list.flatMap { it.getTagsList() }.distinct().sorted()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Image detail query state
    fun getImageById(id: Long): Flow<PromptImage?> {
        return repository.getImageById(id)
    }

    // --- CRUD ---
    fun addImage(
        title: String,
        prompt: String,
        negativePrompt: String? = null,
        uri: String? = null,
        drawableId: Int? = null,
        description: String? = null,
        tags: String = "",
        modelUsed: String = "Unknown",
        aspectRatio: String = "1:1",
        seed: String? = null,
        sampler: String? = null,
        cfg: Float? = null,
        steps: Int? = null,
        isFavorite: Boolean = false,
        rating: Int = 0,
        colorLabel: String? = null,
        collections: String = "",
        folder: String? = null,
        customNotes: String? = null
    ) {
        viewModelScope.launch {
            repository.insertImage(
                PromptImage(
                    title = title.ifBlank { "Untitled Prompt" },
                    prompt = prompt,
                    negativePrompt = negativePrompt,
                    uri = uri,
                    drawableId = drawableId,
                    description = description,
                    tags = tags,
                    modelUsed = modelUsed.ifBlank { "Unknown" },
                    aspectRatio = aspectRatio,
                    seed = seed,
                    sampler = sampler,
                    cfg = cfg,
                    steps = steps,
                    isFavorite = isFavorite,
                    rating = rating,
                    colorLabel = colorLabel,
                    collections = collections,
                    folder = folder,
                    customNotes = customNotes,
                    creationDate = System.currentTimeMillis()
                )
            )
        }
    }

    fun updateImage(image: PromptImage) {
        viewModelScope.launch {
            repository.updateImage(image)
        }
    }

    fun deleteImage(image: PromptImage) {
        viewModelScope.launch {
            repository.deleteImage(image)
        }
    }

    // --- Bulk Operations ---
    fun toggleSelectImage(id: Long) {
        val current = selectedImages.value
        selectedImages.value = if (current.contains(id)) {
            current - id
        } else {
            current + id
        }
    }

    fun clearSelection() {
        selectedImages.value = emptySet()
    }

    fun bulkFavorite(isFavorite: Boolean) {
        val ids = selectedImages.value.toList()
        if (ids.isEmpty()) return
        viewModelScope.launch {
            repository.bulkFavoriteImages(ids, isFavorite)
            clearSelection()
        }
    }

    fun bulkMoveToFolder(folderName: String?) {
        val ids = selectedImages.value.toList()
        if (ids.isEmpty()) return
        viewModelScope.launch {
            repository.bulkMoveToFolder(ids, folderName)
            clearSelection()
        }
    }

    fun bulkAssignCollection(collectionName: String) {
        val ids = selectedImages.value.toList()
        if (ids.isEmpty()) return
        viewModelScope.launch {
            repository.bulkSetCollections(ids, collectionName)
            clearSelection()
        }
    }

    fun bulkAddTags(tags: List<String>) {
        val ids = selectedImages.value.toList()
        if (ids.isEmpty() || tags.isEmpty()) return
        viewModelScope.launch {
            repository.bulkAddTags(ids, tags)
            clearSelection()
        }
    }

    fun bulkDelete() {
        val ids = selectedImages.value.toList()
        if (ids.isEmpty()) return
        viewModelScope.launch {
            repository.deleteImagesByIds(ids)
            clearSelection()
        }
    }

    // --- Templates CRUD ---
    fun addTemplate(
        name: String,
        promptContent: String,
        negativePrompt: String? = null,
        category: String = "General"
    ) {
        viewModelScope.launch {
            repository.insertTemplate(
                PromptTemplate(
                    name = name.ifBlank { "New Template" },
                    promptContent = promptContent,
                    negativePrompt = negativePrompt,
                    category = category.ifBlank { "General" }
                )
            )
        }
    }

    fun updateTemplate(template: PromptTemplate) {
        viewModelScope.launch {
            repository.updateTemplate(template)
        }
    }

    fun deleteTemplate(template: PromptTemplate) {
        viewModelScope.launch {
            repository.deleteTemplate(template)
        }
    }

    // --- Clear all filters helper ---
    fun resetAllFilters() {
        selectedCollectionFilter.value = null
        selectedFolderFilter.value = null
        selectedTagFilter.value = null
        selectedColorFilter.value = null
        searchQuery.value = ""
    }

    // --- Import / Export Logic (JSON, CSV, MD) ---
    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()
    private val backupAdapter = moshi.adapter(PromptLibraryBackup::class.java)

    suspend fun exportAsJson(): String = withContext(Dispatchers.IO) {
        val currentImages = allImages.value
        val currentTemplates = allTemplates.value
        val backup = PromptLibraryBackup(currentImages, currentTemplates)
        backupAdapter.indent("  ").toJson(backup)
    }

    suspend fun importFromJson(jsonString: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val backup = backupAdapter.fromJson(jsonString) ?: return@withContext false
            val imagesToInsert = backup.images.map {
                it.copy(id = 0) // Clear Room ID to insert as new rows safely
            }
            val templatesToInsert = backup.templates.map {
                it.copy(id = 0)
            }
            repository.insertImages(imagesToInsert)
            for (t in templatesToInsert) {
                repository.insertTemplate(t)
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun exportAsCsv(): String = withContext(Dispatchers.IO) {
        val currentImages = allImages.value
        val sb = java.lang.StringBuilder()
        sb.append("ID,Title,Prompt,NegativePrompt,Tags,Model,AspectRatio,Seed,Sampler,CFG,Steps,Favorite,Rating,Notes\n")
        for (img in currentImages) {
            sb.append("${img.id},")
            sb.append("\"${img.title.replace("\"", "\"\"")}\",")
            sb.append("\"${img.prompt.replace("\"", "\"\"")}\",")
            sb.append("\"${(img.negativePrompt ?: "").replace("\"", "\"\"")}\",")
            sb.append("\"${img.tags.replace("\"", "\"\"")}\",")
            sb.append("\"${img.modelUsed}\",")
            sb.append("\"${img.aspectRatio}\",")
            sb.append("\"${img.seed ?: ""}\",")
            sb.append("\"${img.sampler ?: ""}\",")
            sb.append("${img.cfg ?: ""},")
            sb.append("${img.steps ?: ""},")
            sb.append("${img.isFavorite},")
            sb.append("${img.rating},")
            sb.append("\"${(img.customNotes ?: "").replace("\"", "\"\"")}\"\n")
        }
        sb.toString()
    }

    suspend fun exportAsMarkdown(): String = withContext(Dispatchers.IO) {
        val currentImages = allImages.value
        val sb = java.lang.StringBuilder()
        sb.append("# Prompt Gallery Export - ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())}\n\n")
        
        for (img in currentImages) {
            sb.append("## ${img.title}\n\n")
            sb.append("- **AI Model:** ${img.modelUsed}\n")
            sb.append("- **Aspect Ratio:** ${img.aspectRatio}\n")
            if (img.seed != null) sb.append("- **Seed:** ${img.seed}\n")
            if (img.sampler != null) sb.append("- **Sampler:** ${img.sampler}\n")
            if (img.cfg != null) sb.append("- **CFG Scale:** ${img.cfg}\n")
            if (img.steps != null) sb.append("- **Steps:** ${img.steps}\n")
            sb.append("- **Rating:** ${"★".repeat(img.rating)}${"☆".repeat(5 - img.rating)}\n")
            if (img.tags.isNotBlank()) sb.append("- **Tags:** ${img.getTagsList().joinToString(" `#", prefix = "#")}`\n")
            if (img.collections.isNotBlank()) sb.append("- **Collections:** ${img.getCollectionsList().joinToString(", ")}\n")
            if (img.folder != null) sb.append("- **Folder:** ${img.folder}\n")
            sb.append("\n### Prompt\n")
            sb.append("```text\n${img.prompt}\n```\n\n")
            img.negativePrompt?.let { neg ->
                if (neg.isNotBlank()) {
                    sb.append("### Negative Prompt\n")
                    sb.append("```text\n$neg\n```\n\n")
                }
            }
            img.customNotes?.let { notes ->
                if (notes.isNotBlank()) {
                    sb.append("### Custom Notes\n")
                    sb.append("$notes\n\n")
                }
            }
            sb.append("---\n\n")
        }
        sb.toString()
    }

    // Custom ViewModel Factory class
    class Factory(
        private val application: Application,
        private val repository: PromptRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(PromptViewModel::class.java)) {
                return PromptViewModel(application, repository) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
