package com.example

import android.app.Application
import com.example.data.PromptDatabase
import com.example.data.PromptRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class PromptApplication : Application() {

    val database by lazy { PromptDatabase.getDatabase(this) }
    val repository by lazy { PromptRepository(database.promptImageDao(), database.promptTemplateDao()) }

    private val applicationScope = CoroutineScope(Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        
        // Seed database if empty in a background coroutine
        applicationScope.launch {
            repository.prePopulateIfEmpty()
        }
    }
}
