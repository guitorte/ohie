package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.screens.AddEditImageScreen
import com.example.ui.screens.GalleryScreen
import com.example.ui.screens.ImageDetailScreen
import com.example.ui.screens.ImportExportScreen
import com.example.ui.screens.TemplatesScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.PromptViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Setup edge to edge rendering
        enableEdgeToEdge()
        
        setContent {
            MyApplicationTheme {
                // Instantiate our custom ViewModel securely using our manual application lazy container
                val app = application as PromptApplication
                val viewModel: PromptViewModel = viewModel(
                    factory = PromptViewModel.Factory(app, app.repository)
                )
                
                Surface(modifier = Modifier.fillMaxSize()) {
                    val navController = rememberNavController()
                    
                    NavHost(
                        navController = navController,
                        startDestination = "gallery"
                    ) {
                        // Gallery Screen (Main Hub)
                        composable("gallery") {
                            GalleryScreen(
                                viewModel = viewModel,
                                onNavigateToDetail = { id ->
                                    navController.navigate("detail/$id")
                                },
                                onNavigateToAddEdit = { id ->
                                    val route = if (id != null) "add_edit?imageId=$id" else "add_edit"
                                    navController.navigate(route)
                                },
                                onNavigateToTemplates = {
                                    navController.navigate("templates")
                                },
                                onNavigateToImportExport = {
                                    navController.navigate("import_export")
                                }
                            )
                        }
                        
                        // Image Detail screen
                        composable(
                            route = "detail/{imageId}",
                            arguments = listOf(
                                navArgument("imageId") { type = NavType.LongType }
                            )
                        ) { backStackEntry ->
                            val imageId = backStackEntry.arguments?.getLong("imageId") ?: -1L
                            ImageDetailScreen(
                                imageId = imageId,
                                viewModel = viewModel,
                                onNavigateBack = {
                                    navController.popBackStack()
                                },
                                onNavigateToEdit = { id ->
                                    navController.navigate("add_edit?imageId=$id") {
                                        popUpTo("gallery")
                                    }
                                }
                            )
                        }
                        
                        // Add or Edit image entry form
                        composable(
                            route = "add_edit?imageId={imageId}",
                            arguments = listOf(
                                navArgument("imageId") {
                                    type = NavType.StringType
                                    nullable = true
                                    defaultValue = null
                                }
                            )
                        ) { backStackEntry ->
                            val imageIdString = backStackEntry.arguments?.getString("imageId")
                            val imageId = imageIdString?.toLongOrNull()
                            AddEditImageScreen(
                                imageId = imageId,
                                viewModel = viewModel,
                                onNavigateBack = {
                                    navController.popBackStack()
                                }
                            )
                        }
                        
                        // Template manager board
                        composable("templates") {
                            TemplatesScreen(
                                viewModel = viewModel,
                                onNavigateBack = {
                                    navController.popBackStack()
                                }
                            )
                        }
                        
                        // Backup file exporter operations panel
                        composable("import_export") {
                            ImportExportScreen(
                                viewModel = viewModel,
                                onNavigateBack = {
                                    navController.popBackStack()
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
